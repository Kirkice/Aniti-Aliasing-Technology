using Unity.Collections;

namespace UnityEngine.Rendering.Universal
{
    public class HiZCullPass : ScriptableRenderPass
    {
        private HiZRenderFeature.HiZSettings m_hizCullSetting;
        private HiZCullCtrl m_HiZCullCtrlBlock;
        private ProfilingSampler ProfilingSampler = new ProfilingSampler("HizCull");
        private Matrix4x4 lastVP;
        private Vector3 zero = new Vector3(0,0,0);
        
        Vector3[] object_Position;
        Vector3[] object_Extent;
        int ID_DepthTexture;
        int ID_InvSize;
        
        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if(m_HiZCullCtrlBlock.EnableHiZ == false)
                return;
            
            if(renderingData.cameraData.renderType == CameraRenderType.Overlay)
                return;
            
            if(renderingData.cameraData.cameraType != CameraType.Game)
                return;
            
            var camera = renderingData.cameraData.camera;
            var data = m_hizCullSetting.Data;
            var cmd = CommandBufferPool.Get();
            using var profScope = new ProfilingScope(cmd, ProfilingSampler);
            var cs = m_hizCullSetting.CullShader;
            var vp = GL.GetGPUProjectionMatrix(camera.projectionMatrix, false) * Camera.main.worldToCameraMatrix;
            var md = m_hizCullSetting.GameDepthTempRT;

            UpdateMatrixAndExtext();
            
            if (data.CameraType == CameraType.Game)
            {
                #region GenerateMipMap
                int w = 512;
                int h = 512;
                int level = 0;
                
                // RenderTexture lastRt = null;
                if (ID_DepthTexture == 0)
                {
                    ID_DepthTexture = Shader.PropertyToID("_DepthTexture");
                    ID_InvSize = Shader.PropertyToID("_InvSize");
                }

                while (h > 4)
                {
                    data.generateMipMapMaterial.SetVector(ID_InvSize,
                        new Vector4(1.0f / w, 1.0f / h, 0, 0));

                    RenderTexture tempRT = RenderTexture.GetTemporary(w, h, 0, m_hizCullSetting.GameDepthTempRT.format);
                    cmd.Blit(null, tempRT, data.generateMipMapMaterial);
                    cmd.CopyTexture(tempRT, 0, 0, m_hizCullSetting.GameDepthTempRT, 0, level);
                    w /= 2;
                    h /= 2;
                    level++;

                    RenderTexture.ReleaseTemporary(tempRT);
                }
                #endregion
            }

            //commondbuffer 执行方式
            cmd.SetComputeIntParam(cs, HiZRenderFeature.HiZShaderIDs.MaxBufferCountID, m_HiZCullCtrlBlock.OccludeeListCount - 1);
            cmd.SetComputeMatrixParam(cs, HiZRenderFeature.HiZShaderIDs.VPID, vp);
            cmd.SetComputeFloatParam(cs, HiZRenderFeature.HiZShaderIDs.CameraHalfFovID, camera.fieldOfView/2);
            cmd.SetComputeVectorParam(cs, HiZRenderFeature.HiZShaderIDs.CameraPosID, camera.transform.position);
            cmd.SetComputeVectorParam(cs, HiZRenderFeature.HiZShaderIDs.CameraDirID, camera.transform.forward);
            cmd.SetComputeMatrixParam(cs, HiZRenderFeature.HiZShaderIDs.LastVPID, lastVP);
            cmd.SetComputeBufferParam(cs, data.KernelID, HiZRenderFeature.HiZShaderIDs.PositionBufferID, data.PosAllBuffer);
            cmd.SetComputeBufferParam(cs, data.KernelID, HiZRenderFeature.HiZShaderIDs.ExtentBufferID, data.ExtentAllBuffer);

            if (md != null)
                cmd.SetComputeTextureParam(cs, data.KernelID, "_HizDepthMipmap", md);

            cmd.DispatchCompute(cs, data.KernelID, 4, 1, 1);

            if (data.request.done && !data.request.hasError)
            {
                NativeArray<int> instanceData = new NativeArray<int>(data.Count, Allocator.Temp);
                data.request.GetData<int>().CopyTo(instanceData);
                m_HiZCullCtrlBlock.SetOccludeeVisible(instanceData);
                data.request = AsyncGPUReadback.Request(data.VisBuffer);
            }

            // int[] instanceData = new int[data.Count];
            // data.VisBuffer.GetData(instanceData);
            // m_HiZCullCtrlBlock.SetOccludeeVisible(instanceData);
            
            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
            if (Time.frameCount % 10 == 0)
                lastVP = vp;
        }
        
        public void UpdateMatrixAndExtext()
        {
            if(m_HiZCullCtrlBlock.cullType == HiZCullCtrl.CullType.Static)
                return;
            
            if (Time.frameCount % 10 == 0)
            {
                var data = m_hizCullSetting.Data;
                int dataCount = data.Count;
            
                if(data == null)
                    return;

                if(dataCount < m_HiZCullCtrlBlock.OccludeeListCount)
                    return;
            
                if (object_Extent == null || object_Extent == null)
                {
                    object_Position = new Vector3[data.Count];
                    object_Extent = new Vector3[data.Count];   
                }
            
                for (int i = 0; i < dataCount; i++)
                {
                    if (i < m_HiZCullCtrlBlock.OccludeeListCount)
                    {
                        object_Position[i] = m_HiZCullCtrlBlock.occludeeList[i].item.bounds.center;
                        object_Extent[i] = m_HiZCullCtrlBlock.occludeeList[i].item.bounds.extents;
                    }
                    else
                    {
                        object_Position[i] = zero;
                        object_Extent[i] = zero;
                    }
                }
            
                data.PosAllBuffer.SetData(object_Position);
                data.ExtentAllBuffer.SetData(object_Extent);
            
                m_hizCullSetting.CullShader.SetBuffer(data.KernelID, HiZRenderFeature.HiZShaderIDs.PositionBufferID, data.PosAllBuffer);
                m_hizCullSetting.CullShader.SetBuffer(data.KernelID,HiZRenderFeature.HiZShaderIDs.ExtentBufferID,data.ExtentAllBuffer);
            }
        }
        
        // Cleanup any allocated resources that were created during the execution of this render pass.
        public override void OnCameraCleanup(CommandBuffer cmd)
        {
        }

        public override void Configure(CommandBuffer cmd, RenderTextureDescriptor cameraTextureDescriptor)
        {
        }

        public override void OnFinishCameraStackRendering(CommandBuffer cmd)
        {
        }
        
        public HiZCullPass(HiZRenderFeature.HiZSettings hizCullSetting,HiZCullCtrl mHiZCullCtrlBlock)
        {
            m_hizCullSetting = hizCullSetting;
            m_HiZCullCtrlBlock = mHiZCullCtrlBlock;
            renderPassEvent = RenderPassEvent.AfterRenderingPrePasses;
        }

        public void setup(HiZRenderFeature.HiZSettings hizCullSetting,HiZCullCtrl mHiZCullCtrlBlock)
        {
            m_hizCullSetting = hizCullSetting;
            m_HiZCullCtrlBlock = mHiZCullCtrlBlock;
        }
    }
}