using System.Collections.Generic;

namespace UnityEngine.Rendering.Universal
{
    public class HiZRenderFeature : ScriptableRendererFeature
    {
        [System.Serializable]
        public class HiZSettings : System.IDisposable
        {
            public ComputeShader CullShader;
            public ComputeShader GenerateMipmap;
            
            public HiZData Data;
            public RenderTexture GameDepthTempRT;
            
            public void Dispose()
            {
                RenderTexture.ReleaseTemporary(GameDepthTempRT);
            }
        }

        public class HiZData
        {
            public ComputeBuffer PosAllBuffer;
            public ComputeBuffer VisBuffer;
            public ComputeBuffer ExtentAllBuffer;
            public RenderTargetIdentifier DepthTargetIdentifier;
            public RenderTargetIdentifier CurrentPassQueueRenderTexture;
            public CameraType CameraType;
            public int KernelID;
            public int Count;
            public int Width_x;
            public int Width_z;
            public int GenerateMiamapKernelID;
            public AsyncGPUReadbackRequest request;
        }

        public class HiZShaderIDs
        {
            internal static readonly int PositionBufferID = Shader.PropertyToID("AllPositionBuffer");
            internal static readonly int ExtentBufferID = Shader.PropertyToID("AllExtentBuffer");
            internal static readonly int MaxBufferCountID = Shader.PropertyToID("MAX_BUFFER_COUNT");
            internal static readonly int VisibleBufferID = Shader.PropertyToID("visBuffer");
            internal static readonly int VPID = Shader.PropertyToID("VP");
            internal static readonly int CameraHalfFovID = Shader.PropertyToID("_cmrHalfFov");
            internal static readonly int CameraPosID = Shader.PropertyToID("_cmrPos");
            internal static readonly int CameraDirID = Shader.PropertyToID("_cmrPos");
            internal static readonly int LastVPID = Shader.PropertyToID("LastVP");
            internal static readonly int DepthTextureID = Shader.PropertyToID("_CameraDepthTexture");
            internal static readonly int SoureceTexID = Shader.PropertyToID("_SoureceTex");
            internal static readonly int ResultID = Shader.PropertyToID("_Result");
            internal static readonly int MainShadowTextureID = Shader.PropertyToID("_MainLightShadowmapTexture");
        }
        
        [SerializeField] HiZSettings m_HiZSettings = new HiZSettings();
        public HiZCullCtrl mHiZCullCtrlBlock;

        
        private HiZCullPass m_HiZCullPass;

        public override void Create()
        {
            if(mHiZCullCtrlBlock == null)
                return;

            InitFeature();
            m_HiZCullPass = new HiZCullPass(m_HiZSettings, mHiZCullCtrlBlock);
        }

        public void InitFeature()
        {
            //  Init HiZ Data
            m_HiZSettings.Data = new HiZData();
            var data = m_HiZSettings.Data;
            data.Width_x = (int)mHiZCullCtrlBlock.length;
            data.Width_z = (int)mHiZCullCtrlBlock.width;
            data.Count = data.Width_x * data.Width_z;
            data.PosAllBuffer = new ComputeBuffer(data.Count, 3 * 4);
            data.VisBuffer = new ComputeBuffer(data.Count, 4);
            data.ExtentAllBuffer = new ComputeBuffer(data.Count, 3 * 4);
            data.request = AsyncGPUReadback.Request(data.VisBuffer);
            Vector3[] object_Position = new Vector3[data.Count];
            Vector3[] object_Extent = new Vector3[data.Count];
            
            if(data.Count < mHiZCullCtrlBlock.occludeeList.Count)
                return;
            
            for (int i = 0; i < data.Count; i++)
            {
                if (i < mHiZCullCtrlBlock.occludeeList.Count)
                {
                    object_Position[i] = mHiZCullCtrlBlock.occludeeList[i].item.bounds.center;
                    object_Extent[i] = mHiZCullCtrlBlock.occludeeList[i].item.bounds.extents;
                }
                else
                {
                    object_Position[i] = Vector3.zero;
                    object_Extent[i] = Vector3.zero;
                }
            }
            
            data.PosAllBuffer.SetData(object_Position);
            data.ExtentAllBuffer.SetData(object_Extent);
            
            m_HiZSettings.CullShader.SetBuffer(data.KernelID, HiZShaderIDs.PositionBufferID, data.PosAllBuffer);
            m_HiZSettings.CullShader.SetBuffer(data.KernelID, HiZShaderIDs.VisibleBufferID, data.VisBuffer);
            m_HiZSettings.CullShader.SetBuffer(data.KernelID,HiZShaderIDs.ExtentBufferID,data.ExtentAllBuffer);
            
            int[] length = { 100, 1 };
            m_HiZSettings.CullShader.SetInts("lengthX", length);
            data.GenerateMiamapKernelID = m_HiZSettings.GenerateMipmap.FindKernel("Mipmap");

            data.DepthTargetIdentifier = new RenderTargetIdentifier(HiZShaderIDs.DepthTextureID);
            m_HiZSettings.GameDepthTempRT = CreatMipmapDepth();

            data.request = AsyncGPUReadback.Request(data.VisBuffer);
        }

        public void RestFeature()
        {
            InitFeature();
            m_HiZCullPass.setup(m_HiZSettings, mHiZCullCtrlBlock);
        }

        private RenderTexture CreatMipmapDepth()
        {
            RenderTextureDescriptor rtd = new RenderTextureDescriptor(0, 0);
            rtd.autoGenerateMips = false;
            rtd.useMipMap = true;
            rtd.mipCount = 7;
            rtd.height = 512;
            rtd.width = 512;
            rtd.enableRandomWrite = true;
            rtd.colorFormat = RenderTextureFormat.RFloat;
            rtd.volumeDepth = 1;
            rtd.msaaSamples = 1;
            rtd.bindMS = false;
            rtd.dimension = TextureDimension.Tex2D;
            return RenderTexture.GetTemporary(rtd);
        }
        
        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (!(renderingData.cameraData.cameraType == CameraType.Game || renderingData.cameraData.cameraType == CameraType.SceneView))
                return;
            
            if(m_HiZSettings.Data == null)
                return;
            
            //renderer.cameraColorTarget,并不是固定的,不透明之后的物体渲染会更新这个
            m_HiZSettings.Data.CurrentPassQueueRenderTexture = renderer.cameraColorTarget;
            m_HiZSettings.Data.CameraType = renderingData.cameraData.cameraType;
            renderer.EnqueuePass(m_HiZCullPass);
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            m_HiZSettings.Dispose();
        }
    }
}
