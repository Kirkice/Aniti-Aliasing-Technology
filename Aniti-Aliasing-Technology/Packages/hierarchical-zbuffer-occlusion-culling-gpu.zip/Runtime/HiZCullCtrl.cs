using System;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public class HiZCullCtrl : MonoBehaviour
{
    [SerializeField] public UniversalRendererData data;

    [SerializeField] public List<HiZOccludeeData> occludeeList = new List<HiZOccludeeData>();

    [SerializeField] [Range(0.001f, 300.0f)]
    public float length = 10;

    [SerializeField] [Range(0.001f, 300.0f)]
    public float width = 10;

    private int[] visibleArray_Last;
    private HiZRenderFeature feature;
    public bool EnableHiZ = false;

    public void OnDrawGizmos()
    {
        Gizmos.color = new Color(0.2f, 1, 0.2f, 0.7f);
        Gizmos.DrawCube(this.transform.position, new Vector3(length, 10, width));
    }

    private void OnGUI()
    {
        if(GUI.Button(new Rect(10,10,200,50),"初始化HiZ"))
        {
            OnHiZInit();
        }
        
        if(GUI.Button(new Rect(10,10 + 80,200,50),"收集遮挡物"))
        {
            CollectItem();
        }
        
        if(GUI.Button(new Rect(10,10 + 160,200,50),"清理遮挡物"))
        {
            occludeeList.Clear();
        }
        
        if(GUI.Button(new Rect(10,10 + 240,200,50),"开启HiZ"))
        {
            OnEnableHiZ();
        }
        
        if(GUI.Button(new Rect(10,10 + 320,200,50),"关闭HiZ"))
        {
            OnDisableHiZ();
        }
    }

    private void OnHiZInit()
    {
        SetHiZItem();
        InitHiZCullCtrl();
    }

    private void Update()
    {
        UpdateBounds();
    }

    private void OnDisable()
    {
        OnDisableHiZ();
    }

    #region Fun
    /// <summary>
    /// 收集遮挡物
    /// </summary>
    public void CollectItem()
    {
        occludeeList.Clear();

        foreach (HiZCullItem item in UnityEngine.Object.FindObjectsOfType(typeof(HiZCullItem)))
        {
            item.GetAABB();
            Bounds bounds = item.bounds;
            Bounds HiZBox = new Bounds(transform.position,
                new Vector3(length, 10, width));
            if (HiZBox.Intersects(bounds))
            {
                HiZCullCtrl.HiZOccludeeData data = new HiZCullCtrl.HiZOccludeeData();
                data.item = item;
                data.obj = item.gameObject;
                occludeeList.Add(data);
            }
        }
        
        //  初始化上一帧可见物的数组
        visibleArray_Last = new int[occludeeList.Count];
    }
    
    public void SetHiZItem()
    {
        GameObject NPCRoot = GameObject.Find("");
        foreach (GameObject item in NPCRoot.transform)
        {
            if (item.GetComponent<HiZCullItem>() == null)
                item.AddComponent<HiZCullItem>();
        }
    }


    /// <summary>
    /// 初始化HiZ Ctrl
    /// </summary>
    public void InitHiZCullCtrl()
    {
        if (data != null)
        {
            for (int i = 0; i < data.rendererFeatures.Count; i++)
            {
                if (data.rendererFeatures[i].GetType().Name.Equals("HiZRenderFeature"))
                {
                    feature = (HiZRenderFeature) data.rendererFeatures[i];
                    feature.mHiZCullCtrlBlock = this;
                }
            }
        }
        else
            Debug.LogError("请将 UniversalRendererData 拖入组件!");
    }

    /// <summary>
    /// 更新可见性
    /// </summary>
    /// <param name="visible"></param>
    public void SetOccludeeVisible(NativeArray<int> visible)
    {
        for (int i = 0; i < occludeeList.Count; i++)
        {
            if (visible[i] == 0 && visibleArray_Last[i] == 0)
            {
                occludeeList[i].obj.SetActive(false);
            }
            else
            {
                occludeeList[i].obj.SetActive(true);
            }

            if (Time.frameCount % 10 == 0)
                visibleArray_Last[i] = visible[i];
        }
    }

    /// <summary>
    /// 开启HiZ
    /// </summary>
    public void OnEnableHiZ()
    {
        if (occludeeList.Count < 0)
            return;

        if (data == null)
            return;

        if (feature == null)
            return;

        EnableHiZ = true;

        feature.SetActive(true);
        feature.RestFeature();
    }

    private void UpdateBounds()
    {
        if (occludeeList.Count < 0)
            return;

        for (int i = 0; i < occludeeList.Count; i++)
        {
            if (occludeeList[i].obj != null)
                occludeeList[i].item.GetAABB();
        }
    }

    /// <summary>
    /// 关闭HiZ
    /// </summary>
    public void OnDisableHiZ()
    {
        if (occludeeList.Count < 0)
            return;

        if (data == null)
            return;

        if (feature == null)
            return;

        EnableHiZ = false;
        for (int i = 0; i < occludeeList.Count; i++)
        {
            if (occludeeList[i].obj != null)
                occludeeList[i].obj.SetActive(true);
        }

        feature.SetActive(false);
    }

    #endregion

    #region Data

    [System.Serializable]
    public class HiZOccludeeData
    {
        public HiZCullItem item;
        public GameObject obj;
    }

    public enum CullMode
    {
        CPU_CULL = 0,
        GPU_CULL = 1
    }

    #endregion
}