using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HiZCullItem : MonoBehaviour
{
    public bool DebugBounds = false;
    public Bounds bounds;
    
    public void GetAABB()
    {
        bounds = new Bounds();
        Renderer[] renderers = this.GetComponentsInChildren<Renderer>();
        
        if(renderers.Length <= 0)
            return;
        bounds = renderers[0].bounds;
        
        for (int i = 0; i < renderers.Length; i++)
            bounds.Encapsulate(renderers[i].bounds);
    }

    private void OnDrawGizmos()
    {
        if(DebugBounds == false)
            return;
        
        GetAABB();
        
        Vector3 center = bounds.center;
        Vector3 ext = bounds.extents;

        float deltaX = Mathf.Abs(ext.x);
        float deltaY = Mathf.Abs(ext.y);
        float deltaZ = Mathf.Abs(ext.z);

        #region 获取AABB包围盒顶点
        Vector3[] points = new Vector3[8];
        points[0] = center + new Vector3(-deltaX, deltaY, -deltaZ);        // 上前左（相对于中心点）
        points[1] = center + new Vector3(deltaX, deltaY, -deltaZ);         // 上前右
        points[2] = center + new Vector3(deltaX, deltaY, deltaZ);          // 上后右
        points[3] = center + new Vector3(-deltaX, deltaY, deltaZ);         // 上后左

        points[4] = center + new Vector3(-deltaX, -deltaY, -deltaZ);       // 下前左
        points[5] = center + new Vector3(deltaX, -deltaY, -deltaZ);        // 下前右
        points[6] = center + new Vector3(deltaX, -deltaY, deltaZ);         // 下后右
        points[7] = center + new Vector3(-deltaX, -deltaY, deltaZ);        // 下后左
        
        Gizmos.color = Color.red;
        Gizmos.DrawLine(points[0],points[1]);
        Gizmos.DrawLine(points[0],points[3]);
        Gizmos.DrawLine(points[2],points[1]);
        Gizmos.DrawLine(points[2],points[3]);
        
        Gizmos.DrawLine(points[4],points[5]);
        Gizmos.DrawLine(points[4],points[7]);
        Gizmos.DrawLine(points[6],points[5]);
        Gizmos.DrawLine(points[6],points[7]);
        
        Gizmos.DrawLine(points[0],points[4]);
        Gizmos.DrawLine(points[3],points[7]);
        Gizmos.DrawLine(points[2],points[6]);
        Gizmos.DrawLine(points[1],points[5]);
        #endregion
    }
}
