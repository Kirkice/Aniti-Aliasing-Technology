#if UNITY_EDITOR

using UnityEngine;
using UnityEditor;

public class CreateHiZCullEditor : MonoBehaviour
{
    [MenuItem("GameObject/Rendering/Occlusion Cull/Hi-Z Cull", false, 10)]
    static public void LauchHiZCullCtrl()
    {
        if(HaveHiZCullCtrl())
            return;
        
        GameObject mHiZCullCtrl = new GameObject();
        mHiZCullCtrl.AddComponent<HiZCullCtrl>();
        mHiZCullCtrl.name = "HiZCullCtrl";
        mHiZCullCtrl.transform.position = new Vector3(0, 0, 0);
        mHiZCullCtrl.transform.eulerAngles = new Vector3(0, 0, 0);
    }
    
    static private bool HaveHiZCullCtrl()
    {
        foreach (HiZCullCtrl item in UnityEngine.Object.FindObjectsOfType(typeof(HiZCullCtrl)))
            return true;

        return false;
    }
}   
#endif