#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(HiZCullCtrl))]
[CanEditMultipleObjects]
public class HiZCullCtrlEditor : Editor
{
    private static class Styles
    {
        public static readonly GUIContent universalRendererDataLabel = new GUIContent("Renderer Data", "Renderer Data");
        public static readonly GUIContent occludeeListLabel = new GUIContent("被遮挡物", "被遮挡物");
        public static readonly GUIContent hizEnumGPULabel = new GUIContent("HiZ-GPU 枚举", "HiZ-GPU 枚举");
        public static readonly GUIContent hizEnumCPULabel = new GUIContent("HiZ-CPU 枚举", "HiZ-CPU 枚举");
        public static readonly GUIContent cullMode = new GUIContent("剔除模式", "剔除模式");
        
        public static readonly GUIContent cullType = new GUIContent("剔除类型", "剔除类型");
        public static readonly GUIContent MaxExtent = new GUIContent("Extent最大限制(超过不剔除)", "Extent最大限制");
        
        public static readonly GUIContent lengthLabel = new GUIContent("长", "长");
        public static readonly GUIContent widthLabel = new GUIContent("宽", "宽");
        public static readonly GUIContent heightLabel = new GUIContent("高", "高");
    }

    private GUIStyle titleStyle;
    private GUIStyle listTitleStyle;

    private SerializedProperty m_data;
    private SerializedProperty m_occludeeList;
    private SerializedProperty m_length;
    private SerializedProperty m_width;
    private SerializedProperty m_cullType;
    private SerializedProperty m_MaxExtent;

    private void OnEnable()
    {
        if (titleStyle == null)
            GenerateStyles();

        if (listTitleStyle == null)
            GenerateListTitleStyle();

        m_data = serializedObject.FindProperty("data");
        m_occludeeList = serializedObject.FindProperty("occludeeList");
        m_length = serializedObject.FindProperty("length");
        m_width = serializedObject.FindProperty("width");
        m_cullType = serializedObject.FindProperty("cullType");
        m_MaxExtent = serializedObject.FindProperty("MaxExtent");
    }

    private void GenerateStyles()
    {
        titleStyle = new GUIStyle();
        titleStyle.border = new RectOffset(3, 3, 3, 3);
        titleStyle.margin = new RectOffset(2, 2, 2, 2);
        titleStyle.fontSize = 20;
        titleStyle.fontStyle = FontStyle.Bold;
        titleStyle.alignment = TextAnchor.MiddleCenter;
    }

    private void GenerateListTitleStyle()
    {
        listTitleStyle = new GUIStyle();
        listTitleStyle.border = new RectOffset(3, 3, 3, 3);
        listTitleStyle.margin = new RectOffset(2, 2, 2, 2);
        listTitleStyle.normal.textColor = Color.white;
        listTitleStyle.fontSize = 10;
        listTitleStyle.fontStyle = FontStyle.Bold;
        listTitleStyle.alignment = TextAnchor.MiddleLeft;
    }

    Vector2 scroll;

    public override void OnInspectorGUI()
    {
        using (var scope = new GUILayout.ScrollViewScope(scroll))
        {
            scroll = scope.scrollPosition;
            GUILayout.Space(10);
            //  标题GUI
            HeaderGUI();
            GUILayout.Space(10);
            //  HiZ Cull
            HiZCullCtrlGUI();
            GUILayout.Space(5);
        }

        serializedObject.ApplyModifiedProperties();
    }


    public static void BoxGUI(System.Action callback, int paddingH = 5, int paddingV = 5)
    {
        using (new GUILayout.HorizontalScope(GUI.skin.textField))
        {
            GUILayout.Space(paddingH);
            using (new GUILayout.VerticalScope())
            {
                GUILayout.Space(paddingV);
                callback.Invoke();
                GUILayout.Space(paddingV);
            }

            GUILayout.Space(paddingH);
        }
    }

    /// <summary>
    /// 标题GUI
    /// </summary>
    readonly int label_width = 250;

    private void HeaderGUI(int paddingH = 5, int paddingV = 5)
    {
        using (new GUILayout.HorizontalScope(GUI.skin.label))
        {
            GUILayout.Space(paddingH);
            using (new GUILayout.VerticalScope())
            {
                GUILayout.Space(paddingV);
                GUILayout.Box("HiZ Cull", titleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
                GUILayout.Space(paddingV);
            }

            GUILayout.Space(paddingH);
        }
    }


    void HiZCullCtrlGUI()
    {
        HiZCullCtrl mHiZCullCtrl = (HiZCullCtrl) target;

        UniversalRendererDataGUI();

        CullSettingsGUI();
        
        OcclusionAreaGUI();

        ButtonGUI(mHiZCullCtrl);

        OccludeeListGUI();

        serializedObject.ApplyModifiedProperties();
    }

    private void UniversalRendererDataGUI()
    {
        var s = "URP Data.";
        EditorGUILayout.HelpBox(s, MessageType.None);

        BoxGUI(() =>
        {
            EditorGUILayout.LabelField("【URP Data】", listTitleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
            GUILayout.Space(5);
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(m_data, Styles.universalRendererDataLabel, true);
            EditorGUI.indentLevel--;
            GUILayout.Space(10);
        });

        serializedObject.ApplyModifiedProperties();
    }

    private void CullSettingsGUI()
    {
        var s = "剔除设置.";
        EditorGUILayout.HelpBox(s, MessageType.None);

        BoxGUI(() =>
        {
            EditorGUILayout.LabelField("【剔除设置】", listTitleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
            GUILayout.Space(5);
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(m_cullType, Styles.cullType, true);
            EditorGUILayout.PropertyField(m_MaxExtent, Styles.MaxExtent, true);
            EditorGUI.indentLevel--;
            GUILayout.Space(10);
        });

        serializedObject.ApplyModifiedProperties();
    }
    
    private void OcclusionAreaGUI()
    {
        var s = "受遮挡物范围.";
        EditorGUILayout.HelpBox(s, MessageType.None);

        BoxGUI(() =>
        {
            EditorGUILayout.LabelField("【受遮挡物范围】", listTitleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
            GUILayout.Space(5);
            EditorGUI.indentLevel++;
            EditorGUILayout.PropertyField(m_length, Styles.lengthLabel, true);
            EditorGUILayout.PropertyField(m_width, Styles.widthLabel, true);
            EditorGUI.indentLevel--;
            GUILayout.Space(10);
        });

        serializedObject.ApplyModifiedProperties();
    }

    private void OccludeeListGUI()
    {
        var s = "被遮挡物列表.";
        EditorGUILayout.HelpBox(s, MessageType.None);

        EditorGUILayout.LabelField("【被遮挡物列表】", listTitleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
        GUILayout.Space(5);

        EditorGUI.indentLevel++;
        EditorGUILayout.PropertyField(m_occludeeList, Styles.occludeeListLabel, true);
        EditorGUI.indentLevel--;
        GUILayout.Space(10);
    }

    private void ButtonGUI(HiZCullCtrl mHiZCullCtrl)
    {
        var s0 = "收集被遮挡物设置控制.";
        EditorGUILayout.HelpBox(s0, MessageType.None);
        BoxGUI(() =>
        {
            EditorGUILayout.LabelField("【收集被遮挡物】", listTitleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
            GUILayout.Space(5);
            
            EditorGUILayout.BeginHorizontal();
            //  收集被遮挡物体
            if (GUILayout.Button("收集被遮挡物", GUILayout.Width(200)))
            {
                mHiZCullCtrl.CollectItem();
            }

            GUILayout.Space(10);

            //  清理被遮挡物体
            if (GUILayout.Button("清理", GUILayout.Width(200)))
            {
                mHiZCullCtrl.occludeeList.Clear();
            }
            EditorGUILayout.EndHorizontal();
            
            GUILayout.Space(10);

            EditorGUILayout.LabelField("【HiZ 控制】", listTitleStyle, GUILayout.Height(10), GUILayout.ExpandWidth(true));
            GUILayout.Space(5);
            
            EditorGUILayout.BeginHorizontal();

            //  开启HiZ
            if (GUILayout.Button("开启HiZ", GUILayout.Width(200)))
            {
                mHiZCullCtrl.OnEnableHiZ();
            }

            GUILayout.Space(10);

            //  关闭HiZ
            if (GUILayout.Button("关闭HiZ", GUILayout.Width(200)))
            {
                mHiZCullCtrl.OnDisableHiZ();
            }

            GUILayout.Space(10);
            EditorGUILayout.EndHorizontal();
        });
    }
}
#endif